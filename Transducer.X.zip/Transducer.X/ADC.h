#ifndef ADC_H
#define ADC_H
#include <xc.h>
#include <stdbool.h>

#define ADC_BLOCK_SIZE  256

typedef enum {
    ADC_STATE_IDLE,
    ADC_STATE_SEARCHING,
    ADC_STATE_FOUND
} adc_state_t;

void ADC_Init(void);
void ADC_StartCapture(void);
void ADC_ResetState(void);
void ADC_Tasks(void);
adc_state_t ADC_GetState(void);
float ADC_GetDistancia(void);
uint16_t ADC_GetNivelBase(void);

#endif