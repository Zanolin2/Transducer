#include "mcc_generated_files/system.h"
#include "Potenciometro.h"
#include "Excitacion.h"
#include "ADC.h"
#include "LCD_I2C.h"
#include <stdio.h>
#include <string.h>
#define FCY 40535000UL
#include <libpic30.h>

int main(void)
{
    SYSTEM_Initialize();
    Excitation_Init();
    LCD_Init();
    ADC_Init();

    LCD_PrintWrapped("Transducer UNMDP", "Iniciando...");
    __delay_ms(2000);

    char txt[17];
    char txt_anterior[17] = "";
    uint16_t ciclos = 0;

    while (1)
    {
        if (ADC_GetState() == ADC_STATE_FOUND)
        {
            float dist = ADC_GetDistancia();
            uint16_t base = ADC_GetNivelBase();

            char debug[17];
            sprintf(debug, "B:%d D:%.2f", base, (double)dist);
            LCD_PrintWrapped("Debug:", debug);
            __delay_ms(500);

            ADC_ResetState();
        }
    }
    return 0;
}