#ifndef Excitacion_H
#define Excitacion_H

/**
 * @brief Inicializa el m�dulo de excitaci�n.
 * Configura el timer, la interrupci�n y el estado inicial de los pines.
 */
void Excitation_Init(void);

/**
 * @brief Ejecuta la m�quina de estados de excitaci�n.
 * Esta funci�n debe ser llamada repetidamente en el bucle principal (while(1)).
 */
void Excitation_Tasks(void);

#endif 