#include "ADC.h"
#include "mcc_generated_files/dma.h"
#include "mcc_generated_files/adc1.h"

#define FCY 40535000UL
#include <libpic30.h>

#define F_SAMPLING                 1000000.0f
#define VELOCIDAD_SONIDO           1500.0f
#define UMBRAL_ECO                 400
#define ZONA_MUERTA_TOTAL_SAMPLES  300

uint16_t bufferA[ADC_BLOCK_SIZE] __attribute__((aligned(256)));
uint16_t bufferB[ADC_BLOCK_SIZE] __attribute__((aligned(256)));

static volatile adc_state_t g_state = ADC_STATE_IDLE;
static volatile uint32_t g_total_samples_processed = 0;
static volatile float g_distancia_detectada = 0.0;
static volatile bool procesar_buffer_A = true;
static volatile uint16_t nivel_base = 200; // valor inicial conservador
static volatile uint32_t base_suma_final = 0;
static volatile uint8_t base_count_final = 0;

void ADC_Init(void) {
    g_state = ADC_STATE_IDLE;
}

void ADC_ResetState(void) {
    g_state = ADC_STATE_IDLE;
}

void ADC_StartCapture(void) {
    if (g_state == ADC_STATE_SEARCHING) return;

    g_state = ADC_STATE_SEARCHING;
    g_total_samples_processed = 0;
    g_distancia_detectada = 0.0;
    procesar_buffer_A = true;

    DMA0STAL = (uint16_t)&bufferA;
    DMA0STAH = 0;
    DMA0STBL = (uint16_t)&bufferB;
    DMA0STBH = 0;
    DMA0CNT = ADC_BLOCK_SIZE - 1;

    IFS0bits.DMA0IF = 0;
    DMA0CONbits.CHEN = 1;
    AD1CON1bits.ADON = 1;
    AD1CON1bits.ASAM = 1;
}

bool ProcesarBloque(uint16_t* buffer, uint32_t offset_muestras) {
    for (int i = 0; i < ADC_BLOCK_SIZE; i++) {
        uint32_t indice_absoluto = offset_muestras + i;

        if (indice_absoluto < ZONA_MUERTA_TOTAL_SAMPLES) continue;
        if (indice_absoluto > 12500) return true;

        // Capturar piso real en los �ltimos 50 samples de la ventana
        if (indice_absoluto > 12400 && indice_absoluto <= 12450) {
            base_suma_final += buffer[i];
            base_count_final++;
            if (base_count_final >= 50) {
                nivel_base = (uint16_t)(base_suma_final / 50);
                base_suma_final = 0;
                base_count_final = 0;
            }
        }

        if (buffer[i] > nivel_base + UMBRAL_ECO) {
            float tiempo = (float)indice_absoluto / F_SAMPLING;
            g_distancia_detectada = (tiempo * VELOCIDAD_SONIDO) / 2.0f;
            return true;
        }
    }
    return false;
}

void DMA_Channel0_CallBack(void) {
    if (g_state != ADC_STATE_SEARCHING) return;

    bool encontrado = false;

    if (procesar_buffer_A) {
        encontrado = ProcesarBloque(bufferA, g_total_samples_processed);
    } else {
        encontrado = ProcesarBloque(bufferB, g_total_samples_processed);
    }

    procesar_buffer_A = !procesar_buffer_A;
    g_total_samples_processed += ADC_BLOCK_SIZE;

    if (encontrado || g_total_samples_processed > 13000) {
        AD1CON1bits.ASAM = 0;
        DMA0CONbits.CHEN = 0;
        AD1CON1bits.ADON = 0;
        g_state = ADC_STATE_FOUND;
    }
}

float ADC_GetDistancia(void) {
    return g_distancia_detectada;
}

adc_state_t ADC_GetState(void) {
    return g_state;
}

uint16_t ADC_GetNivelBase(void) {
    return nivel_base;
}

void ADC_Tasks(void) {}